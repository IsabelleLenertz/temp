package Model;

import java.util.*;

/**
 * 
 */
public class GameModel {

    /**
     * Default constructor
     */
    public GameModel() {
    }

    /**
     * @return
     */
    public Set<Relic> Relics() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<Person> Persons() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<ExcavationTool> ExcavationTools() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<ExploitationTool> ExploitationTools() {
        // TODO implement here
        return null;
    }

}