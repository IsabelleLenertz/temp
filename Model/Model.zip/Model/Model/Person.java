package Model;

import java.util.*;

/**
 * 
 */
public class Person {

    /**
     * Default constructor
     */
    public Person() {
    }

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String desc;

    /**
     * 
     */
    private JobEnum jobs;



}