package Model;

/**
 * 
 */
public enum JobEnum {
}