package Model;

/**
 * 
 */
public enum State {
    SELECT,
    UNSELECT,
    UNAVAILABLE
}