package Model;

import java.util.*;

/**
 * 
 */
public class ExcavationTool {

    /**
     * Default constructor
     */
    public ExcavationTool() {
    }

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String desc;

    /**
     * 
     */
    private JobEnum requirements;



}