package Control;

import java.util.*;

/**
 * 
 */
public class GameControleur {

    /**
     * Default constructor
     */
    public GameControleur() {
    }



    /**
     * @param String personName
     */
    public void highlightPerson(void String personName) {
        // TODO implement here
    }

    /**
     * @param String excavactionToolName
     */
    public void highlightExcavationTool(void String excavactionToolName) {
        // TODO implement here
    }

    /**
     * @param String exploitationToolName
     */
    public void highlightExploitationTool(void String exploitationToolName) {
        // TODO implement here
    }

    /**
     * @param String relicName
     */
    public void highlightRelic(void String relicName) {
        // TODO implement here
    }

    /**
     * 
     */
    public void clearHighlight() {
        // TODO implement here
    }

    /**
     * 
     */
    public void nextStage() {
        // TODO implement here
    }

    /**
     * @param name 
     * @return
     */
    public State getPersonStatus(String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param name 
     * @return
     */
    public String getPersonName(String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param name 
     * @return
     */
    public String getPersonName(String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param name 
     * @return
     */
    public String getPersonDesc(String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param name 
     * @return
     */
    public String getPersonImage(String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param name 
     * @return
     */
    public Set<String> getPersonJobs(String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param name 
     * @return
     */
    public State getExcavationToolStatus(String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param String name 
     * @return
     */
    public String getExcavationToolName(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public String getExcavationToolDesc(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public Set<String> getExcavationToolRequirements(void String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param String name 
     * @return
     */
    public State getExploitationToolStatus(void String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param String name 
     * @return
     */
    public String getExploitationToolName(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public String getExploitationToolDesc(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public Set<String> getExploitationToolRequirements(void String name) {
        // TODO implement here
        return null;
    }

    /**
     * @param String name 
     * @return
     */
    public String getRelicName(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public String getRelicDesc(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @param String name 
     * @return
     */
    public String getRelicImage(void String name) {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Set<String> getPersonsList() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<String> getExcavationToolsList() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<String> getExploitationToolsList() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<String> getFoundRelicsList() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Set<String> getAvailableJobs() {
        // TODO implement here
        return null;
    }

    /**
     * @param String name
     */
    public void selectPerson(void String name) {
        // TODO implement here
    }

    /**
     * @param String name
     */
    public void unselectPerson(void String name) {
        // TODO implement here
    }

    /**
     * @param String name
     */
    public void selectExcavationTool(void String name) {
        // TODO implement here
    }

    /**
     * @param String name
     */
    public void unselectExcavationTool(void String name) {
        // TODO implement here
    }

    /**
     * @param String name
     */
    public void selectExploitationTool(void String name) {
        // TODO implement here
    }

    /**
     * @param String name
     */
    public void unselectExploitationTool(void String name) {
        // TODO implement here
    }

    /**
     * @return
     */
    public SideInfos getSideInfo() {
        // TODO implement here
        return null;
    }

}