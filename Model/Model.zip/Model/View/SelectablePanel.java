package View;

import java.util.*;

/**
 * 
 */
public class SelectablePanel {

    /**
     * Default constructor
     */
    public SelectablePanel() {
    }

    /**
     * 
     */
    public enum state;

    /**
     * 
     */
    private JButton button;

    /**
     * 
     */
    private String name;



    /**
     * 
     */
    public void Uptade() {
        // TODO implement here
    }

    /**
     * @param name 
     * @param g
     */
    public void SelectablePanel(String name, GameControleur g) {
        // TODO implement here
    }

}