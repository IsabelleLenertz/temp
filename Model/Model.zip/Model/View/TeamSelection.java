package View;

import java.util.*;

/**
 * 
 */
public class TeamSelection extends StageView {

    /**
     * Default constructor
     */
    public TeamSelection() {
    }

    /**
     * 
     */
    public void Attribute1;

}