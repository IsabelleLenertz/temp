package View;

import java.util.*;

/**
 * 
 */
public abstract class StageView {

    /**
     * Default constructor
     */
    public StageView() {
    }

    /**
     * 
     */
    private Panel ressourcesPanel;

    /**
     * 
     */
    private Panel displayInfos;

    /**
     * 
     */
    private Panel panelContaint;

    /**
     * 
     */
    private JButton buttonNext;


    /**
     * @param g
     */
    public void StageView(GameControleur g) {
        // TODO implement here
    }

}