package View;

import java.util.*;

/**
 * 
 */
public class ResultsView {

    /**
     * Default constructor
     */
    public ResultsView() {
    }

}