package View;

import java.util.*;

/**
 * 
 */
public class mainMenuView {

    /**
     * Default constructor
     */
    public mainMenuView() {
    }

    /**
     * 
     */
    public Panel selectionScenario;

}