package View;

import java.util.*;

/**
 * 
 */
public class ExcavationVIew extends StageView {

    /**
     * Default constructor
     */
    public ExcavationVIew() {
    }

}