package View;

import java.util.*;

/**
 * 
 */
public class SelectableExcavationToolPanel extends SelectablePanel {

    /**
     * Default constructor
     */
    public SelectableExcavationToolPanel() {
    }

}