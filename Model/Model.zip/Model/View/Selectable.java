package View;

import java.util.*;

/**
 * 
 */
public class Selectable {

    /**
     * Default constructor
     */
    public Selectable() {
    }

}