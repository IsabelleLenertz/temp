package View;

import java.util.*;

/**
 * 
 */
public class SelectablePersonPanel extends SelectablePanel {

    /**
     * Default constructor
     */
    public SelectablePersonPanel() {
    }

}